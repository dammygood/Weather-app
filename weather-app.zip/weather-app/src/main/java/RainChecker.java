public class RainChecker {

    private final WeatherService weatherService = new WeatherService();

    public String checkRain(String city1, String city2) throws Exception {
        boolean rainCity1 = weatherService.isRaining(city1);
        boolean rainCity2 = weatherService.isRaining(city2);

        if (rainCity1 && rainCity2) {
            return "It's raining in both " + city1 + " and " + city2 + "!";
        } else if (rainCity1) {
            return "It's raining in " + city1 + ".";
        } else if (rainCity2) {
            return "It's raining in " + city2 + ".";
        } else {
            return "It's not raining in either city.";
        }
    }
}