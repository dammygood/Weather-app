public class DaylightComparator {

    private final WeatherService weatherService = new WeatherService();

    public String compareDaylight(String city1, String city2) throws Exception {
        long sunrise1 = weatherService.getSunrise(city1);
        long sunset1 = weatherService.getSunset(city1);
        long daylight1 = sunset1 - sunrise1;

        long sunrise2 = weatherService.getSunrise(city2);
        long sunset2 = weatherService.getSunset(city2);
        long daylight2 = sunset2 - sunrise2;

        return daylight1 > daylight2 ? city1 : city2;
    }
}