import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class WeatherService {

    private static final String API_KEY = "YOUR_OPENWEATHERMAP_API_KEY";
    private static final String BASE_URL = "https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s";

    private final OkHttpClient client = new OkHttpClient();

    public JsonObject getWeatherData(String cityName) throws Exception {
        String url = String.format(BASE_URL, cityName, API_KEY);
        Request request = new Request.Builder().url(url).build();
        try (Response response = client.newCall(request).execute()) {
            String responseData = response.body().string();
            return JsonParser.parseString(responseData).getAsJsonObject();
        }
    }

    public long getSunrise(String cityName) throws Exception {
        JsonObject weatherData = getWeatherData(cityName);
        return weatherData.getAsJsonObject("sys").get("sunrise").getAsLong();
    }

    public long getSunset(String cityName) throws Exception {
        JsonObject weatherData = getWeatherData(cityName);
        return weatherData.getAsJsonObject("sys").get("sunset").getAsLong();
    }

    public boolean isRaining(String cityName) throws Exception {
        JsonObject weatherData = getWeatherData(cityName);
        if (weatherData.has("rain")) {
            return true;
        }
        return false;
    }
}