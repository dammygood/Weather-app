import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        WeatherService weatherService = new WeatherService();
        DaylightComparator daylightComparator = new DaylightComparator();
        RainChecker rainChecker = new RainChecker();
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Enter first city:");
            String city1 = scanner.nextLine();

            System.out.println("Enter second city:");
            String city2 = scanner.nextLine();

            System.out.println("Checking which city has longer daylight...");
            String longerDaylightCity = daylightComparator.compareDaylight(city1, city2);
            System.out.println("City with longer daylight: " + longerDaylightCity);

            System.out.println("Checking rain status...");
            String rainStatus = rainChecker.checkRain(city1, city2);
            System.out.println(rainStatus);

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}