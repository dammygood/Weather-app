# Weather Comparison Java App

This is a simple Java command-line application that compares two cities based on:
- Daylight Hours (sunrise to sunset)
- Current Rain Status

It uses the OpenWeatherMap API for weather data.

## Setup

1. Get a free API key from [OpenWeatherMap](https://openweathermap.org/api).
2. Replace `YOUR_OPENWEATHERMAP_API_KEY` in `WeatherService.java`.
3. Build the project:

```bash
mvn clean install
```

4. Run the app:

```bash
java -cp target/weather-app-1.0.jar Main
```

## Dependencies

- OkHttp
- Gson